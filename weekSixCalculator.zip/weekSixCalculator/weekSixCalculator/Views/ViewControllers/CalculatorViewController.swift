//
//  CalculatorViewController.swift
//  weekSixCalculator
//
//  Created by Collins on 12/14/20.
//

import UIKit

class CalculatorViewController: UIViewController {
    
    
    var numberOnScreen:Int = 0;
    var previousNumber:Int = 0;
    var performingMath = false
    var operation = 0;
    
    
    //Mark:- Outlets
    
    @IBOutlet weak var label: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    
    // Mark:- Actions
    
    
    
    @IBAction func clearButtonTapped(_ sender: Any) {
        label.text = ""
    }
    
    
    @IBAction func numbers(_ sender: UIButton) {
        if performingMath == true {
            
            label.text = label.text! + String(sender.tag-1)
            numberOnScreen = Int(label.text!)!
            performingMath = false
            
        }
        else
        {
            label.text = label.text! + String(sender.tag-1)
            numberOnScreen = Int(label.text!)!
        }
        
       
    }
    
    
    @IBAction func clearButton(_ sender: UIButton) {
        
        
        if label.text != "" && sender.tag != 11 && sender.tag != 16
        {
            previousNumber = Int(label.text!)!
            
            if sender.tag == 12 // Divide
            {
                label.text = "/";
            }
            else if sender.tag == 13 // Multiply
            {
                label.text = "x";
            }
            else if sender.tag == 14 // Subtraction
            {
                label.text = "-";
            }
            else if sender.tag == 15 // Addition
            {
                label.text = "+";
            }
            
            operation = sender.tag
            performingMath = true;
        }
        else if sender.tag == 16
        {
            if operation == 12
            {
                label.text = String(previousNumber / numberOnScreen)
            }
            else if operation == 13
            {
                label.text = String(previousNumber * numberOnScreen)
            }
            
            else if operation == 14
            {
                label.text = String(previousNumber - numberOnScreen)
            }
            else if operation == 15
            {
                label.text = String(previousNumber + numberOnScreen)
            }
            else if sender.tag == 11
            {
                label.text = ""
//                previousNumber = 0;
//                numberOnScreen = 0;
//                operation = 0;
                
            }
        }
        
    }

}
